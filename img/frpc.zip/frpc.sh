#!/bin/bash

echo "初始化 frps.ini 配置文件..."
if [[ ! -d /home/frp ]]; then mkdir /home/frp; fi
cat>/home/frp/frpc.ini<<EOF

[common]
server_addr = 47.108.196.229
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
use_encryption = true
use_compression = true

[web]
type = http
local_port = 80

custom_domains = 47.108.196.229
use_encryption = true
use_compression = true

EOF
echo "启动frpc 容器..."

docker rm -f frpc
docker run --restart=always --network host -d -v /home/frp/frpc.ini:/etc/frp/frpc.ini --name frpc snowdreamtech/frpc
