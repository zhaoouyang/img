#!/bin/bash
echo "初始化 frps.ini 配置文件..."
if [[ ! -d /home/frp/frpc-web ]]; then mkdir /home/frp/frpc-web; fi
cat>/home/frp/frpc-web/frpc.ini<<EOF
[common]
server_addr = 47.108.196.229
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
use_encryption = true
use_compression = true

[web]
type = http
local_ip = 192.168.3.101
local_port = 9999
custom_domains = frps.yuzhanvip.com
use_encryption = true
use_compression = true
EOF

echo "启动frpc 容器..."
docker rm -f frpc
docker run --restart=always --network host -d -v /home/frp/frpc-web/frpc.ini:/etc/frp/frpc.ini --name frpc-web snowdreamtech/frpc

